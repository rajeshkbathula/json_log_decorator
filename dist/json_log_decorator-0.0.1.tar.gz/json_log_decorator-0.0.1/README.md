# json_log_decorator
python log decorator with exception raise and captures time taken by function or method 
